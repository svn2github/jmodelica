package org.ant4eclipse.lib.jdt.ecj;

public interface ReferableSourceFile extends SourceFile, ReferableType {

}
