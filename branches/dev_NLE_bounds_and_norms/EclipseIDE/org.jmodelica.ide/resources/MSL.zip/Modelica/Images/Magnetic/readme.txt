All files in this directory and in all subdirectories are
licensed by the Modelica Association under the Modelica License 2.
Copyright � 2005-2009, Thomas B�drich.

These files are free software and the use is completely at your own risk;
they can be redistributed and/or modified under the terms of the Modelica
license 2, see the license conditions (including the disclaimer of warranty)
at http://www.modelica.org/modelica-legal-documents/ModelicaLicense2.html.
