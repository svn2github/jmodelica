All files in this directory (Modelica) and in all subdirectories,
especially in Modelica\C-sources, Modelica\help, Modelica\Images are
licensed by the Modelica Association under the Modelica License 2
(with exception of files "Modelica\C-sources\win32_dirent.*").
Copyright � 1998-2009, ABB, arsenal research, DLR, Dynasim, Fraunhofer, Modelon,
                       TU Hamburg-Harburg, Politecnico di Milano.

These files are free software and the use is completely at your own risk;
they can be redistributed and/or modified under the terms of the
Modelica license 2, see the license conditions (including the disclaimer of warranty)
in file Modelica\ModelicaLicense2.html
or at http://www.modelica.org/modelica-legal-documents/ModelicaLicense2.html.

Licensor:
Modelica Association
(Ideella F�reningar 822003-8858 in Link�ping)
c/o PELAB, IDA, Link�pings Universitet
S-58183 Link�ping
Sweden
email: Board@Modelica.org
web  : http://www.Modelica.org
